<?php

defined (LOCALHOST) ?null: define (LOCALHOST, 'localhost') ;
defined (USERNAME) ?null: define (USERNAME, ' root ') ;
defined (PASSWORD) ?null: define (PASSWORD, ' ') ;
defined (DBNAME) ?null: define (DBNAME, ' eBus') ;




$conn = mysqli_connect (LOCALHOST, USERNAME, PASSWORD, DBNAME) or die (
"Connection to DB failed");
}

function connection(){
global $conn;
return $conn;
}

function query ($str) {
global $conn;
$q = "select * from products";
return mysqli_query ($q, $conn) ;
}

function check ($results) {
	global $conns;
if (! $results) {
echo mysqli_error ($conn) ;}}

?>