<?php
include_once('..\config.php');

// حذف تصنيف
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $deleteQuery = "DELETE FROM products_db WHERE id = $id";
    mysqli_query($conn, $deleteQuery);
    header("Location: categories.php");
    exit();
}
?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Categories</h1>
            <div class="card mb-4">
                <div class="card-body">
                    <?php getCategories(); ?>
                </div>
            </div>
        </div>
    </main>
    <?php include("adminFooter.php");?>
</div>
