<?php
session_start();
if(!isset($_SESSION['username']))
    header('Location:..\login.php');

if($_SESSION['role']!=1)
    header('Location:..\login.php');

include('..\config.php');

if (isset($_POST['delete_user'])) {
    $id = intval($_POST['user_id']);
    $delete_query = "DELETE FROM users WHERE user_id = $id";
    mysqli_query($conn, $delete_query);
}

if (isset($_POST['update_user'])) {
    $id       = intval($_POST['user_id']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $role     = intval($_POST['role']);

    $update_query = "UPDATE users 
                     SET username = '$username', password = '$password', role = $role
                     WHERE user_id = $id";
    mysqli_query($conn, $update_query);
}

function adminGetAllUsers() {
    global $conn;
    $q = "SELECT * FROM users ORDER BY user_id ASC";
    $results = mysqli_query($conn, $q);

    if(!$results) {
        return "<tr><td colspan='5'>Query failed: " . mysqli_error($conn) . "</td></tr>";
    }

    $output = "";
    while ($row = mysqli_fetch_assoc($results)) {
        $id       = $row['user_id'];
        $username = htmlspecialchars($row['username']);
        $password = htmlspecialchars($row['password']);
        $role     = $row['role'];

        $output .= "
        <tr>
            <td>{$id}</td>
            <td>
                <span id='username-display-{$id}'>{$username}</span>
                <input type='text' id='username-input-{$id}' style='display:none;' value='{$username}'>
                <input type='hidden' name='username' id='username-hidden-{$id}' value='{$username}'>
            </td>
            <td>
                <span id='password-display-{$id}'>{$password}</span>
                <input type='text' id='password-input-{$id}' style='display:none;' value='{$password}'>
                <input type='hidden' name='password' id='password-hidden-{$id}' value='{$password}'>
            </td>
            <td>
                <span id='role-display-{$id}'>{$role}</span>
                <input type='number' id='role-input-{$id}' style='display:none;' value='{$role}'>
                <input type='hidden' name='role' id='role-hidden-{$id}' value='{$role}'>
            </td>
            <td>
                <form method='POST' style='display:inline-block;'>
                    <input type='hidden' name='user_id' value='{$id}'>
                    <button type='submit' name='delete_user' class='btn btn-danger btn-sm'>
                        <i class='fas fa-trash'></i>
                    </button>
                </form>
                <form method='POST' style='display:inline-block;'>
                    <input type='hidden' name='user_id' value='{$id}'>
                    <input type='hidden' name='username' id='username-hidden-{$id}' value='{$username}'>
                    <input type='hidden' name='password' id='password-hidden-{$id}' value='{$password}'>
                    <input type='hidden' name='role' id='role-hidden-{$id}' value='{$role}'>
                    <button type='submit' name='update_user' id='save-button-{$id}' style='display:none;' class='btn btn-success btn-sm'>
                        <i class='fas fa-save'></i>
                    </button>
                </form>
                <button class='btn btn-primary btn-sm' onclick='makeEditable({$id})'>
                    <i class='fas fa-edit'></i>
                </button>
            </td>
        </tr>";
    }
    return $output;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Users - Fruitables Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
<?php include('adminTopBar.php'); ?>
<div id="layoutSidenav">
    <?php include('adminSideNav.php'); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Users</h1>
                <div class="card mb-4">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>User ID</th>
                                    <th>Username</th>
                                    <th>Password</th>
                                    <th>Role</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php echo adminGetAllUsers(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
        <?php include('adminFooter.php'); ?>
    </div>
</div>
<script>
function makeEditable(id) {
    document.getElementById(`username-display-${id}`).style.display = 'none';
    document.getElementById(`username-input-${id}`).style.display = 'inline';

    document.getElementById(`password-display-${id}`).style.display = 'none';
    document.getElementById(`password-input-${id}`).style.display = 'inline';

    document.getElementById(`role-display-${id}`).style.display = 'none';
    document.getElementById(`role-input-${id}`).style.display = 'inline';

    document.getElementById(`save-button-${id}`).style.display = 'inline';

    document.getElementById(`username-input-${id}`).addEventListener('input', function () {
        document.getElementById(`username-hidden-${id}`).value = this.value;
    });
    document.getElementById(`password-input-${id}`).addEventListener('input', function () {
        document.getElementById(`password-hidden-${id}`).value = this.value;
    });
    document.getElementById(`role-input-${id}`).addEventListener('input', function () {
        document.getElementById(`role-hidden-${id}`).value = this.value;
    });
}
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>
