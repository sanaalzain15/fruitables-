<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h1 class="mt-4">welcome to fruitables admin panel</h1>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item active">admin panel </li>
                        </ol>

                       <?php include ("adminMainCard.php");?>
                       <?php include ("adminMainChart.php");?>
                       <?php include ("adminMainCard.php");?>
                       <?php include ("adminMainTable.php");?>

				    </div>
                </main>
               
<?php include("adminFooter.php");?>
</div>
       