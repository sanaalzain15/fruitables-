<?php
session_start();
if(!isset($_SESSION['username']))
    header('Location:..\login.php');

if($_SESSION['role']!=1)
    header('Location:..\login.php');

include_once('..\config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <title>Orders - Fruitables Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
</head>
<body class="sb-nav-fixed">
<?php include("adminTopBar.php"); ?>
<div id="layoutSidenav">
    <?php include("adminSideNav.php"); ?>
    <div id="layoutSidenav_content">
        <main>
            <div class="container-fluid px-4">
                <h1 class="mt-4">Orders</h1>
                <div class="card mb-4">
                    <div class="card-body">
                        <?php
                        $q = "SELECT transaction_id, id, status, amount, currency FROM transactionss ORDER BY transaction_id DESC";
                        $results = mysqli_query($conn, $q);

                        echo "<table class='table table-striped'>";
                        echo "<thead>
                                <tr>
                                    <th>Transaction ID</th>
                                    <th>Order/User ID</th>
                                    <th>Status</th>
                                    <th>Amount</th>
                                    <th>Currency</th>
                                </tr>
                              </thead><tbody>";
                        while($row = mysqli_fetch_assoc($results)) {
                            echo "<tr>";
                            echo "<td>{$row['transaction_id']}</td>";
                            echo "<td>{$row['id']}</td>";
                            echo "<td>{$row['status']}</td>";
                            echo "<td>{$row['amount']}</td>";
                            echo "<td>{$row['currency']}</td>";
                            echo "</tr>";
                        }
                        echo "</tbody></table>";
                        ?>
                    </div>
                </div>
            </div>
        </main>
        <?php include("adminFooter.php"); ?>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"></script>
<script src="js/datatables-simple-demo.js"></script>
</body>
</html>
